package utilities;

public enum NotificationResults {
    deleted,
    created,
    updated,
    added,
    Error
    ;
}
