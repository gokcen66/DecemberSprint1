package utilities;

public enum Buttons {
    Yes,
    No,
    Close,
    Save
    ;
}
