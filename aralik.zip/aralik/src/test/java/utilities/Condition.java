package utilities;

public enum Condition {
    exists,
    visible,
    appear,
    invisible,
    disappear,
    enabled,
    clickable
    ;


}
